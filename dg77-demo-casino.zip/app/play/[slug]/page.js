"use client";
import Topbar from "@/app/components/Topbar";
import Link from "next/link";
import { listGames, getCurrent } from "@/app/lib/demoStore";
import { useMemo } from "react";

function DemoGame() {
  // Mini-joguinho demo (só visual), sem RNG real e sem apostas.
  return (
    <div className="panel" style={{textAlign:"center"}}>
      <div style={{fontSize:13, color:"var(--muted)"}}>Mini game DEMO</div>
      <div style={{fontSize:28, fontWeight:900, margin:"8px 0"}}>🍀 🍀 🍀</div>
      <div className="small">Toque em “Girar” para trocar os símbolos (apenas animação).</div>
      <div style={{height:12}} />
      <button className="btn" onClick={()=>{
        const items = ["🐯","🍀","💎","⭐","🍒","7️⃣"];
        const pick = () => items[Math.floor(Math.random()*items.length)];
        const el = document.getElementById("reels");
        if (el) el.textContent = `${pick()} ${pick()} ${pick()}`;
      }}>Girar</button>
      <div id="reels" style={{fontSize:32, marginTop:12, fontWeight:900}}>🐯 💎 ⭐</div>
    </div>
  );
}

export default function Play({ params }) {
  const me = useMemo(() => getCurrent(), []);
  const game = useMemo(() => listGames().find(g => g.slug === params.slug), [params.slug]);

  return (
    <>
      <Topbar />
      <div className="panel">
        <div style={{display:"flex", alignItems:"center", justifyContent:"space-between", gap:10}}>
          <div>
            <div style={{fontWeight:900, fontSize:18}}>{game ? game.name : "Jogo"}</div>
            <div className="small">DEMO • Sem dinheiro real</div>
          </div>
          <Link className="btn secondary" href="/">Voltar</Link>
        </div>
      </div>

      {!me ? (
        <div className="notice" style={{marginTop:12}}>
          Você precisa <b>entrar</b> para jogar. <Link href="/login" style={{textDecoration:"underline"}}>Ir para login</Link>
        </div>
      ) : (
        <DemoGame />
      )}
    </>
  );
}
