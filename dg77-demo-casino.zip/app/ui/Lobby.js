"use client";
import Link from "next/link";
import { listGames } from "@/app/lib/demoStore";
import { useMemo } from "react";

export default function Lobby() {
  const games = useMemo(() => listGames(), []);
  return (
    <>
      <div className="notice">
        <b>Modo DEMO:</b> isto é apenas um protótipo para testar layout, login e painel ADM.
        Não há pagamentos, saques ou jogos oficiais/licenciados aqui.
      </div>

      <div className="grid">
        {games.map((g, idx) => (
          <div className="card" key={g.slug}>
            <div className="img">
              <span className="badge">{idx % 2 === 0 ? "🔥 Popular" : "⭐ Novo"}</span>
            </div>
            <div className="body">
              <p className="title">{g.name}</p>
              <p className="sub">{g.provider} • Demo</p>
              <div className="row">
                <Link className="btn" href={`/play/${g.slug}`}>Jogar</Link>
                <span className="pill">RTP {g.rtp}</span>
              </div>
            </div>
          </div>
        ))}
      </div>
    </>
  );
}
