"use client";
import Topbar from "@/app/components/Topbar";
import { login, register, getCurrent } from "@/app/lib/demoStore";
import { useEffect, useState } from "react";

export default function LoginPage() {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [msg, setMsg] = useState("");

  useEffect(() => {
    const me = getCurrent();
    if (me) location.href = "/";
  }, []);

  return (
    <>
      <Topbar />
      <div className="panel">
        <h3 style={{margin:"6px 0 10px 0"}}>Entrar</h3>
        <input className="input" placeholder="Usuário" value={username} onChange={e=>setUsername(e.target.value)} />
        <div style={{height:10}} />
        <input className="input" placeholder="Senha" type="password" value={password} onChange={e=>setPassword(e.target.value)} />
        <div style={{height:12}} />
        <div style={{display:"flex", gap:10}}>
          <button className="btn" onClick={()=>{
            const r = login(username.trim(), password);
            setMsg(r.ok ? "" : r.error);
            if (r.ok) location.href="/";
          }}>Entrar</button>
          <button className="btn secondary" onClick={()=>{
            const r = register(username.trim(), password);
            setMsg(r.ok ? "" : r.error);
            if (r.ok) location.href="/";
          }}>Criar conta</button>
        </div>
        {msg ? <div className="notice" style={{borderColor:"rgba(255,77,109,.35)"}}>{msg}</div> : null}

        <div className="notice">
          <b>Login ADM (demo):</b><br/>
          usuário: <b>admin</b><br/>
          senha: <b>admin123</b>
        </div>
      </div>
    </>
  );
}
