import "./globals.css";

export const metadata = {
  title: "DG77 • Casino Demo",
  description: "Plataforma DEMO para testes (sem dinheiro real)."
};

export default function RootLayout({ children }) {
  return (
    <html lang="pt-BR">
      <body>
        <div className="wrap">{children}</div>
      </body>
    </html>
  );
}
