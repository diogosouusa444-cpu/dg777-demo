"use client";
import Topbar from "@/app/components/Topbar";
import { getCurrent, listUsers, adjustBalance } from "@/app/lib/demoStore";
import { useEffect, useState } from "react";

export default function AdminPage() {
  const [me, setMe] = useState(null);
  const [users, setUsers] = useState([]);
  const [target, setTarget] = useState("");
  const [bal, setBal] = useState("5000");
  const [msg, setMsg] = useState("");

  function refresh(){
    setMe(getCurrent());
    setUsers(listUsers());
  }

  useEffect(() => { refresh(); }, []);

  if (!me) {
    return (
      <>
        <Topbar />
        <div className="notice">Faça login para acessar o ADM.</div>
      </>
    );
  }

  if (me.role !== "admin") {
    return (
      <>
        <Topbar />
        <div className="notice">Acesso negado. Somente ADMIN.</div>
      </>
    );
  }

  return (
    <>
      <Topbar />
      <div className="panel">
        <h3 style={{margin:"6px 0 10px 0"}}>Painel ADM (DEMO)</h3>

        <div className="notice">
          Aqui é só para testes no navegador. Os dados ficam no <b>localStorage</b> (não é banco real).
        </div>

        <div style={{display:"grid", gap:10, marginTop:12}}>
          <input className="input" placeholder="Usuário alvo (ex: diogo)" value={target} onChange={e=>setTarget(e.target.value)} />
          <input className="input" placeholder="Novo saldo demo" value={bal} onChange={e=>setBal(e.target.value)} />
          <button className="btn" onClick={()=>{
            const r = adjustBalance(target.trim(), bal);
            setMsg(r.ok ? "Saldo atualizado!" : r.error);
            refresh();
          }}>Atualizar saldo</button>
          {msg ? <div className="notice">{msg}</div> : null}
        </div>

        <div style={{height:14}} />
        <div className="small" style={{marginBottom:8}}>Usuários (demo)</div>
        <div style={{display:"grid", gap:8}}>
          {users.map(u => (
            <div key={u.username} className="card" style={{padding:12}}>
              <div style={{display:"flex", justifyContent:"space-between", gap:10, alignItems:"center"}}>
                <div>
                  <div style={{fontWeight:900}}>{u.username} <span className="pill" style={{marginLeft:8}}>{u.role}</span></div>
                  <div className="small">Saldo: {u.balance}</div>
                </div>
                <button className="btn secondary" onClick={()=>{
                  setTarget(u.username);
                  setBal(String(u.balance));
                  window.scrollTo({top:0, behavior:"smooth"});
                }}>Editar</button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </>
  );
}
