# DG77 • Casino DEMO (Mobile) + Painel ADM

**Atenção:** Este projeto é **apenas DEMO/protótipo**.  
- Não possui pagamentos/saques.
- Não inclui jogos oficiais/licenciados (PG/Pragmatic etc.).
- Serve para testar layout, login e painel ADM.

## Rodar local
```bash
npm install
npm run dev
```

## Deploy grátis (mais fácil): Vercel
1. Suba este código para um repositório no GitHub
2. Entre na Vercel, Import Project, selecione o repo
3. Deploy

## Login ADM (demo)
- usuário: `admin`
- senha: `admin123`

## Rotas
- `/` lobby
- `/login`
- `/play/[slug]`
- `/admin`
